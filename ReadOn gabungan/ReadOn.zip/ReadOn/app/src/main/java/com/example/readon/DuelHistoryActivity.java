package com.example.readon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.readon.model.Duel;

import java.util.ArrayList;

public class DuelHistoryActivity extends AppCompatActivity {
    private ArrayList<Duel> duelList;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {    
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_duel_history);

        recyclerView = findViewById(R.id.recyclerView);
        duelList = new ArrayList<>();

        setDuelData();
        setAdapter();

    }

    private void setAdapter(){
        RecyclerAdapter adapter = new RecyclerAdapter(duelList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    private void setDuelData(){
        duelList.add(new Duel("24/04/2021", "Marcel", "Speed Reading", "3", "100", "50", "You", 1));
        duelList.add(new Duel("23/04/2021","Jason", "Number of Book / Text Read", "48", "200", "250", "Jason", 0));
        duelList.add(new Duel("22/04/2021","Ferdinand", "Point Competition", "3", "200", "450", "Ferdinand", 0));

    }
}