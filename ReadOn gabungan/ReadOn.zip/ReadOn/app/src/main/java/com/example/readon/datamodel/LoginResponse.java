package com.example.readon.datamodel;

public class LoginResponse {
    private String userId;

    public String getUserId() {
        return userId;
    }
}
