package com.example.readon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.readon.backgroundservice.StatusService;
import com.example.readon.pref.AppPreference;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomeActivity extends AppCompatActivity {
    
    private Button button,button2,button3, buttonedit;
    private AppPreference appPreference;
    private TextView username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //StatusService.test(this, new Intent());

        username = findViewById(R.id.username);

        appPreference = new AppPreference(this);

        username.setText(appPreference.getUserLoggedInUsername());

        button = (Button) findViewById(R.id.duel);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveduel();
            }
        });

        button2 = (Button) findViewById(R.id.challenge);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                movechal();
            }
        });

        button3 = (Button) findViewById(R.id.tips);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                movetips();
            }
        });

        buttonedit = (Button) findViewById(R.id.edit);
        buttonedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!appPreference.isLogin()) {
            gotoFrontActivity();
        }
    }

    private void gotoFrontActivity() {
        Intent frontIntent = new Intent(this, FrontActivity.class);
        startActivity(frontIntent);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile:
                moveprofile();
                return true;
            case R.id.shelf:
                moveshelf();
                return true;
            case R.id.library:
                movelibrary();
                return true;
            case R.id.friend:
                movefriend();
                return true;
            case R.id.tips:
                movetips();
                return true;
            case R.id.logout:
                appPreference.logout();
                gotoFrontActivity();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void moveprofile(){
        Intent i = new Intent(this, ProfileActivity.class);
        startActivity(i);
    }
    public void moveshelf(){
        Intent i = new Intent(this, ShelfActivity.class);
        startActivity(i);
    }
    public void movelibrary(){
        Intent i = new Intent(this, LibraryActivity.class);
        startActivity(i);
    }
    public void movefriend(){
        Intent i = new Intent(this, FriendlistActivity.class);
        startActivity(i);
    }
    public void movetips(){
        Intent i = new Intent(this, TipsActivity.class);
        startActivity(i);
    }
    public void moveduel(){
        Intent i = new Intent(this, DuelActivity.class);
        startActivity(i);
    }
    public void movechal(){
        Intent i = new Intent(this, ChallengeActivity.class);
        startActivity(i);
    }
    public void edit(){
        Intent i = new Intent(this, EditprofileActivity.class);
        startActivity(i);
    }

}