package com.example.readon.service;

import com.example.readon.datamodel.duel.DuelResponse;
import com.example.readon.datamodel.FriendlistResponse;
import com.example.readon.datamodel.FriendreqResponse;
import com.example.readon.datamodel.LoginResponse;
import com.example.readon.datamodel.SearchUserResponse;
import com.example.readon.datamodel.duel.SendDuelRequest;
import com.example.readon.model.Friendlist;
import com.example.readon.model.User;
import com.example.readon.datamodel.APIResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface APIService {
    @POST("/signup")
    public Call<APIResponse> signup(@Body User user);

    @POST("/login")
    public Call<APIResponse<LoginResponse>> login(@Body User user);

    @POST("/sendotp")
    public Call<APIResponse> sendotp(@Body User user);

    @POST("/compareotp")
    public Call<APIResponse> compareotp(@Body User user);

    @POST("/changepassword")
    public Call<APIResponse> changepassword(@Body User user);

    @POST("/viewfriendlist")
    public Call<APIResponse<List<FriendlistResponse>>> viewfriendlist(@Body User user);

    @POST("/deletefriend")
    public Call<APIResponse> deletefriend(@Body Friendlist friendlist);

    @POST("/searchuser")
    public Call<APIResponse<SearchUserResponse>> searchuser(@Body User user);

    @POST("/addfriend")
    public Call<APIResponse> addfriend(@Body Friendlist friendlist);

    @POST("/viewfriendreq")
    public Call<APIResponse<List<FriendreqResponse>>> viewfriendreq(@Body User user);

    @POST("/friendaccept")
    public Call<APIResponse> friendaccept(@Body Friendlist friendlist);

    @POST("/friendreject")
    public Call<APIResponse> friendreject(@Body Friendlist friendlist);

    @POST("/statusonline")
    public Call<APIResponse> statusonline(@Body User user);

    @POST("/statusoffline")
    public Call<APIResponse> statusoffline(@Body User user);

    @POST("/requestlist")
    Call<APIResponse<List<DuelResponse>>> viewDuelRequest(@Body User user);

    @POST("/sendduel")
    Call<APIResponse> sendDuelRequest(@Body SendDuelRequest request);

    @POST("/duelresponse")
    Call<APIResponse> acceptDuel(@Body SendDuelRequest request);

    @POST("/deleterequest")
    Call<APIResponse> declineDuel(@Body SendDuelRequest request);
}
