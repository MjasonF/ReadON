package com.example.readon.datamodel.duel;

import com.example.readon.datamodel.UserItemResponse;
import com.google.gson.annotations.SerializedName;

public class DuelResponse {

    @SerializedName("_id")
    private String duelId;

    @SerializedName("user_id")
    private UserItemResponse user;

    private String type;

    @SerializedName("created_at")
    private String createdAt;

    public String getDuelId() {
        return duelId;
    }

    public UserItemResponse getUser() {
        return user;
    }

    public String getType() {
        return type;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}
