package com.example.readon.model;

public class Duel {

    private String duelId;
    private String title, request, type, time, point1, point2, winner;
    private Integer result;
    private Boolean expanded;
    private String opponentUsername;
    private String opponentUserId;

    public Boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(Boolean expanded) {
        this.expanded = expanded;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Duel() {}

    public Duel(String title, String request, String type, String time, String point1, String point2, String winner, Integer result) {
        this.title = title;
        this.request = request;
        this.type = type;
        this.time = time;
        this.point1 = point1;
        this.point2 = point2;
        this.winner = winner;
        this.result = result;
        this.expanded = false;
    }
    public String getDuelId() {
        return duelId;
    }

    public void setDuelId(String duelId) {
        this.duelId = duelId;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPoint1() {
        return point1;
    }

    public void setPoint1(String point1) {
        this.point1 = point1;
    }

    public String getPoint2() {
        return point2;
    }

    public void setPoint2(String point2) {
        this.point2 = point2;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }

    public String getOpponentUsername() {
        return opponentUsername;
    }

    public String getOpponentUserId() {
        return opponentUserId;
    }

    public void setOpponentUsername(String opponentUsername) {
        this.opponentUsername = opponentUsername;
    }

    public void setOpponentUserId(String opponentUserId) {
        this.opponentUserId = opponentUserId;
    }
}
